"use strict";

document.addEventListener("DOMContentLoaded", () => {
  const $ = id => document.getElementById(id);
  const SAVE_KEY = "turboRacersSave_v2";

  const defaults = {
    avatar: null, points: 0, course: 1, bestPosition: null, bestTime: null,
    unlockedItems: [], ownedCars: ["starter"], track: null, totalRaces: 0
  };

  const clone = o => JSON.parse(JSON.stringify(o));
  let save = loadSave();

  function loadSave() {
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      if (!raw) return clone(defaults);
      return { ...clone(defaults), ...JSON.parse(raw) };
    } catch (e) { console.error(e); return clone(defaults); }
  }
  function saveGame() {
    try { localStorage.setItem(SAVE_KEY, JSON.stringify(save)); }
    catch (e) { console.error("Sauvegarde impossible", e); }
  }
  function showScreen(id) {
    document.querySelectorAll(".screen").forEach(s => s.classList.add("hidden"));
    const target = $(id); if (target) target.classList.remove("hidden");
  }
  function clamp(v,a,b){ return Math.max(a,Math.min(b,v)); }

  // ---------- AVATAR ----------
  const avatarFields = ["avatarName","avatarGender","avatarAge","avatarHeight","avatarHair","avatarHairColor","avatarGlasses","avatarHelmet","avatarMask"];
  function getAvatar() {
    return {
      name: ($("avatarName").value || "").trim() || "Pilote",
      gender: $("avatarGender").value,
      age: $("avatarAge").value,
      height: $("avatarHeight").value,
      hair: $("avatarHair").value,
      hairColor: $("avatarHairColor").value,
      glasses: $("avatarGlasses").value,
      helmet: $("avatarHelmet").value,
      mask: $("avatarMask").value,
      outfit: save.avatar?.outfit || "neutral"
    };
  }
  function paintAvatar(root, a) {
    if (!root || !a) return;
    root.innerHTML = `
      <div class="hair"></div><div class="face"></div><div class="body"></div>
      <div class="glasses"></div><div class="helmet"></div><div class="avatar-mask"></div>`;
    const hair=root.querySelector(".hair"), face=root.querySelector(".face"), body=root.querySelector(".body");
    const glasses=root.querySelector(".glasses"), helmet=root.querySelector(".helmet"), mask=root.querySelector(".avatar-mask");
    hair.className="hair "+a.hair; hair.style.background=a.hairColor;
    face.style.borderRadius=a.gender==="A"?"45%":"42%";
    const scales={small:.88,medium:1,tall:1.12}; root.style.setProperty("--avatar-scale",scales[a.height]||1);
    root.style.transform=`scale(${scales[a.height]||1})`;
    const outfit={neutral:"#eee",blue:"#397bd1",red:"#d84040",black:"#151515",gold:"#d4af37"};
    body.style.background=outfit[a.outfit]||outfit.neutral;
    if(a.glasses!=="none"){glasses.style.display="block";glasses.style.borderRadius=a.glasses==="round"?"50%":a.glasses==="sport"?"4px":"8px"}
    const helmets={none:"transparent",white:"#eee",red:"#d84040",blue:"#397bd1",black:"#151515",gold:"#d4af37"};
    helmet.style.background=helmets[a.helmet]||"transparent"; helmet.style.display=a.helmet==="none"?"none":"block";
    const masks={none:"transparent",white:"#eee",black:"#151515",blue:"#397bd1",red:"#d84040"};
    mask.style.background=masks[a.mask]||"transparent"; mask.style.display=a.mask==="none"?"none":"block";
  }
  function updateAvatarPreview(){ paintAvatar($("previewAvatar"),getAvatar()); }
  function loadAvatarForm(){
    if(!save.avatar) return;
    const a=save.avatar;
    $("avatarName").value=a.name||""; $("avatarGender").value=a.gender||"A"; $("avatarAge").value=a.age||"teen";
    $("avatarHeight").value=a.height||"medium"; $("avatarHair").value=a.hair||"short"; $("avatarHairColor").value=a.hairColor||"#24170f";
    $("avatarGlasses").value=a.glasses||"none"; $("avatarHelmet").value=a.helmet||"none"; $("avatarMask").value=a.mask||"none";
    updateAvatarPreview();
  }
  avatarFields.forEach(id => {
    $(id).addEventListener("input",updateAvatarPreview);
    $(id).addEventListener("change",updateAvatarPreview);
  });
  $("createAvatarBtn").addEventListener("click",e=>{
    e.preventDefault();
    const first=!save.avatar;
    save.avatar=getAvatar();
    if(first){ save.points=0; save.course=1; save.totalRaces=0; save.unlockedItems=[]; }
    saveGame(); updateMenu(); showScreen("menuScreen");
  });
  $("avatarCancelBtn").addEventListener("click",()=>{ updateMenu(); showScreen("menuScreen"); });

  // ---------- MENU ----------
  function updateMenu(){
    if(!save.avatar) return;
    $("welcomeText").textContent=`Bienvenue, ${save.avatar.name} !`;
    $("menuPoints").textContent=save.points; $("garagePoints").textContent=save.points; $("hudPoints").textContent=save.points;
    $("courseNumber").textContent=Math.min(save.course,200); $("bestPosition").textContent=save.bestPosition||"-";
    $("bestTime").textContent=save.bestTime==null?"-":save.bestTime.toFixed(2)+" s";
    paintAvatar($("menuAvatar"),save.avatar);
  }
  $("customizeBtn").addEventListener("click",()=>{
    loadAvatarForm(); $("avatarHeading").textContent="Modifie ton pilote"; $("createAvatarBtn").textContent="💾 Enregistrer les modifications";
    $("avatarCancelBtn").classList.remove("hidden"); showScreen("avatarScreen");
  });
  $("garageBtn").addEventListener("click",()=>{renderShop();showScreen("garageScreen")});
  $("garageBackBtn").addEventListener("click",()=>{updateMenu();showScreen("menuScreen")});
  $("resetBtn").addEventListener("click",()=>{
    if(!confirm("Effacer toute ta progression ?")) return;
    localStorage.removeItem(SAVE_KEY); save=clone(defaults); $("avatarHeading").textContent="Crée ton pilote";
    $("createAvatarBtn").textContent="🏁 Créer mon pilote"; $("avatarCancelBtn").classList.add("hidden");
    $("avatarName").value=""; updateAvatarPreview(); showScreen("avatarScreen");
  });

  // ---------- GARAGE ----------
  const shopItems=[
    {id:"outfit_blue",name:"Tenue bleue",price:500,type:"outfit",value:"blue"},
    {id:"outfit_red",name:"Tenue rouge",price:500,type:"outfit",value:"red"},
    {id:"outfit_black",name:"Tenue noire",price:500,type:"outfit",value:"black"},
    {id:"outfit_gold",name:"Tenue dorée",price:1000,type:"outfit",value:"gold"},
    {id:"helmet_gold",name:"Casque doré",price:350,type:"helmet",value:"gold"},
    {id:"glasses_sport",name:"Lunettes sport",price:250,type:"glasses",value:"sport"},
    {id:"mask_black",name:"Masque noir",price:300,type:"mask",value:"black"}
  ];
  function renderShop(){
    const c=$("shopItems"); c.innerHTML="";
    shopItems.forEach(item=>{
      const owned=save.unlockedItems.includes(item.id);
      const d=document.createElement("div"); d.className="shop-item";
      d.innerHTML=`<h3>${item.name}</h3><p>⭐ ${item.price}</p><button ${owned?"disabled":""}>${owned?"✓ Débloqué":"Acheter"}</button>`;
      d.querySelector("button").addEventListener("click",()=>{
        if(owned||save.points<item.price){if(save.points<item.price&&!owned)alert("Tu n'as pas assez de points !");return}
        save.points-=item.price; save.unlockedItems.push(item.id);
        save.avatar[item.type]=item.value; saveGame(); renderShop(); updateMenu();
      }); c.appendChild(d);
    });
  }

  // ---------- TRACK EDITOR ----------
  const editorCanvas=$("editorCanvas"), ectx=editorCanvas.getContext("2d");
  let trackPoints=[], undoStack=[], redoStack=[], drawing=false;
  let trackWidth=110;

  function resizeEditor(){
    const r=editorCanvas.getBoundingClientRect(), d=Math.min(devicePixelRatio||1,2);
    editorCanvas.width=r.width*d; editorCanvas.height=r.height*d; ectx.setTransform(d,0,0,d,0,0); drawEditor();
  }
  window.addEventListener("resize",()=>{if(!$("editorScreen").classList.contains("hidden"))resizeEditor()});
  function pointFromEvent(ev){
    const r=editorCanvas.getBoundingClientRect(); return {x:ev.clientX-r.left,y:ev.clientY-r.top};
  }
  function saveUndo(){undoStack.push(trackPoints.map(p=>({...p})));if(undoStack.length>30)undoStack.shift();redoStack=[]}
  function normalizeTrack(points){
    if(points.length<20)return null;
    const clean=[]; let last=null;
    points.forEach(p=>{if(!last||Math.hypot(p.x-last.x,p.y-last.y)>3){clean.push(p);last=p}});
    if(clean.length<20)return null;
    const first=clean[0], lastP=clean[clean.length-1];
    if(Math.hypot(first.x-lastP.x,first.y-lastP.y)>trackWidth*1.7) return null;
    return clean;
  }
  function drawEditor(){
    const w=editorCanvas.clientWidth,h=editorCanvas.clientHeight; ectx.clearRect(0,0,w,h);
    ectx.fillStyle="#245f3d"; ectx.fillRect(0,0,w,h);
    if(trackPoints.length){
      ectx.save(); ectx.lineCap="round"; ectx.lineJoin="round";
      ectx.beginPath(); trackPoints.forEach((p,i)=>i?ectx.lineTo(p.x,p.y):ectx.moveTo(p.x,p.y));
      if(trackPoints.length>2) ectx.lineTo(trackPoints[0].x,trackPoints[0].y);
      ectx.lineWidth=trackWidth+28; ectx.strokeStyle="#171717"; ectx.stroke();
      ectx.lineWidth=trackWidth; ectx.strokeStyle="#555"; ectx.stroke();
      ectx.lineWidth=5; ectx.setLineDash([20,18]); ectx.strokeStyle="#eee"; ectx.stroke(); ectx.setLineDash([]);
      const p=trackPoints[0]; ectx.fillStyle="#18c96e"; ectx.fillRect(p.x-18,p.y-8,36,16);
      ectx.fillStyle="#111"; ectx.fillRect(p.x-18,p.y-8,9,16); ectx.fillRect(p.x,p.y-8,9,16);
      ectx.restore();
    } else {
      ectx.fillStyle="rgba(255,255,255,.55)"; ectx.font="bold 22px Arial"; ectx.textAlign="center";
      ectx.fillText("Dessine ton circuit ici",w/2,h/2);
    }
  }
  function pointerDown(ev){
    if(ev.pointerType==="mouse"&&ev.button!==0)return;
    drawing=true; saveUndo(); const p=pointFromEvent(ev); trackPoints=[p]; editorCanvas.setPointerCapture?.(ev.pointerId); drawEditor();
    $("editorHint").textContent="Continue à dessiner… relâche pour fermer la boucle.";
  }
  function pointerMove(ev){if(!drawing)return;const p=pointFromEvent(ev),last=trackPoints[trackPoints.length-1];if(Math.hypot(p.x-last.x,p.y-last.y)>4){trackPoints.push(p);drawEditor()}}
  function pointerUp(){if(!drawing)return;drawing=false;
    if(trackPoints.length>1){const first=trackPoints[0],last=trackPoints[trackPoints.length-1];if(Math.hypot(first.x-last.x,first.y-last.y)<trackWidth*1.7){trackPoints.push({...first})}else{alert("Le circuit doit revenir près de son point de départ.");undoStack.pop();trackPoints=[]}}
    drawEditor(); $("editorHint").textContent="Circuit prêt ! Tu peux le tester.";
  }
  editorCanvas.addEventListener("pointerdown",pointerDown); editorCanvas.addEventListener("pointermove",pointerMove);
  editorCanvas.addEventListener("pointerup",pointerUp); editorCanvas.addEventListener("pointercancel",()=>{drawing=false});
  $("trackWidthInput").addEventListener("input",e=>{trackWidth=+e.target.value;drawEditor()});
  $("undoTrackBtn").addEventListener("click",()=>{if(!undoStack.length)return;redoStack.push(trackPoints.map(p=>({...p})));trackPoints=undoStack.pop()||[];drawEditor()});
  $("redoTrackBtn").addEventListener("click",()=>{if(!redoStack.length)return;undoStack.push(trackPoints.map(p=>({...p})));trackPoints=redoStack.pop()||[];drawEditor()});
  $("clearTrackBtn").addEventListener("click",()=>{if(!trackPoints.length)return;saveUndo();trackPoints=[];drawEditor()});
  function makeSample(){
    const w=editorCanvas.clientWidth,h=editorCanvas.clientHeight,cx=w/2,cy=h/2;
    trackPoints=[]; for(let i=0;i<180;i++){const t=i/180*Math.PI*2;const r=250+55*Math.sin(t*3)+25*Math.cos(t*5);trackPoints.push({x:cx+Math.cos(t)*r,y:cy+Math.sin(t)*r*.62})}
    trackPoints.push({...trackPoints[0]}); undoStack=[];redoStack=[];drawEditor();
  }
  $("sampleTrackBtn").addEventListener("click",makeSample);
  $("createTrackBtn").addEventListener("click",()=>{showScreen("editorScreen");requestAnimationFrame(resizeEditor)});
  $("editorBackBtn").addEventListener("click",()=>{updateMenu();showScreen("menuScreen")});
  $("testTrackBtn").addEventListener("click",()=>{
    const t=normalizeTrack(trackPoints); if(!t){alert("Dessine une boucle fermée assez longue.");return}
    save.track={points:t,width:trackWidth,w:editorCanvas.clientWidth,h:editorCanvas.clientHeight};
    saveGame(); startRace();
  });

  // ---------- RACE ----------
  const canvas=$("gameCanvas"),ctx=canvas.getContext("2d");
  let race=null, frame=0, lastTime=0;
  const keys={up:false,down:false,left:false,right:false};
  let accel=false,brake=false;
  const joy={x:0,y:0,active:false};

  function resizeGame(){
    const d=Math.min(devicePixelRatio||1,2); canvas.width=innerWidth*d;canvas.height=innerHeight*d;ctx.setTransform(d,0,0,d,0,0);
  }
  window.addEventListener("resize",resizeGame);
  function startRace(){
    if(!save.track){alert("Crée d'abord un circuit.");return}
    const pts=save.track.points.map(p=>({x:p.x,y:p.y}));
    const scaleX=innerWidth/save.track.w,scaleY=innerHeight/save.track.h;
    const track=pts.map(p=>({x:p.x*scaleX,y:p.y*scaleY}));
    race={track,width:save.track.width*((scaleX+scaleY)/2),drivers:[],start:performance.now(),elapsed:0,finished:false};
    const s=track[0], n=track[1], angle=Math.atan2(n.y-s.y,n.x-s.x);
    race.drivers=[{name:save.avatar.name,isPlayer:true,x:s.x,y:s.y,angle,speed:0,progress:0,lap:0,dist:0,finished:false},
      ...["Max Falcon","Luna Storm","Niko Blaze","Maya Flash"].map((name,i)=>({name,isPlayer:false,x:s.x-Math.cos(angle)*(55+i*42),y:s.y-Math.sin(angle)*(55+i*42),angle,speed:1.7+i*.08,progress:-i*.3,lap:0,dist:-i*30,finished:false}))];
    resizeGame();showScreen("gameScreen");cancelAnimationFrame(frame);lastTime=0;frame=requestAnimationFrame(loop);
  }
  function nearestOnTrack(x,y){
    let best={d:Infinity,index:0,t:0};
    for(let i=0;i<race.track.length-1;i++){const a=race.track[i],b=race.track[i+1],dx=b.x-a.x,dy=b.y-a.y,len2=dx*dx+dy*dy;let t=((x-a.x)*dx+(y-a.y)*dy)/(len2||1);t=clamp(t,0,1);const px=a.x+dx*t,py=a.y+dy*t,d=Math.hypot(x-px,y-py);if(d<best.d)best={d,index:i,t}}
    return best;
  }
  function trackDistance(index,t){
    let d=0;for(let i=0;i<index;i++)d+=Math.hypot(race.track[i+1].x-race.track[i].x,race.track[i+1].y-race.track[i].y);
    const a=race.track[index],b=race.track[index+1];return d+t*Math.hypot(b.x-a.x,b.y-a.y);
  }
  function totalTrackLength(){let d=0;for(let i=0;i<race.track.length-1;i++)d+=Math.hypot(race.track[i+1].x-race.track[i].x,race.track[i+1].y-race.track[i].y);return d}
  function updatePlayer(d,dt){
    const accelerating=keys.up||accel||joy.y<-.25, braking=keys.down||brake||joy.y>.35;
    d.speed += (accelerating?.055: -.025)*dt; if(braking)d.speed-=.09*dt; d.speed=clamp(d.speed,0,5.5);
    let steer=(keys.left?-1:0)+(keys.right?1:0); if(Math.abs(joy.x)>.12)steer=joy.x;
    d.angle+=steer*.055*Math.max(.25,d.speed/5.5)*dt;
    d.x+=Math.cos(d.angle)*d.speed*dt;d.y+=Math.sin(d.angle)*d.speed*dt;
    const near=nearestOnTrack(d.x,d.y), margin=race.width*.52;
    if(near.d>margin)d.speed*=Math.pow(.82,dt/16);
    d.dist=trackDistance(near.index,near.t);
    const total=race.total; d.progress=d.lap*total+d.dist;
    if(d.dist<race.width*.45 && d.progress>total*.85 && d.lap<3)d.lap++;
  }
  function updateAI(d,dt){
    const target=race.track[Math.min(race.track.length-1,Math.floor((d.dist/race.total)*race.track.length))];
    const desired=Math.atan2(target.y-d.y,target.x-d.x);
    let diff=Math.atan2(Math.sin(desired-d.angle),Math.cos(desired-d.angle));d.angle+=clamp(diff,-.045*dt,.045*dt);
    d.speed=clamp(d.speed+.03*dt,0,2.7);d.x+=Math.cos(d.angle)*d.speed*dt;d.y+=Math.sin(d.angle)*d.speed*dt;
    const near=nearestOnTrack(d.x,d.y);d.dist=trackDistance(near.index,near.t);d.progress=d.lap*race.total+d.dist;
    if(d.dist<race.width*.45&&d.progress>race.total*.85&&d.lap<3)d.lap++;
  }
  function loop(t){
    if(!race||race.finished)return;const dt=Math.min(32,t-(lastTime||t));lastTime=t;race.elapsed=(t-race.start)/1000;
    race.drivers[0].speed*=1;updatePlayer(race.drivers[0],dt);race.drivers.slice(1).forEach(d=>updateAI(d,dt));
    if(race.drivers[0].progress>=race.total*3)finishRace();
    drawRace();updateHUD();if(race&&!race.finished)frame=requestAnimationFrame(loop);
  }
  function drawRace(){
    const w=innerWidth,h=innerHeight,p=race.drivers[0],ox=w/2-p.x,oy=h/2-p.y;
    ctx.clearRect(0,0,w,h);ctx.save();ctx.translate(ox,oy);
    ctx.fillStyle="#245f3d";ctx.fillRect(-2000,-2000,4000,4000);
    ctx.lineCap="round";ctx.lineJoin="round";ctx.beginPath();race.track.forEach((q,i)=>i?ctx.lineTo(q.x,q.y):ctx.moveTo(q.x,q.y));
    ctx.lineWidth=race.width+30;ctx.strokeStyle="#161616";ctx.stroke();ctx.lineWidth=race.width;ctx.strokeStyle="#555";ctx.stroke();
    ctx.lineWidth=4;ctx.setLineDash([18,18]);ctx.strokeStyle="#eee";ctx.stroke();ctx.setLineDash([]);
    race.drivers.forEach((d,i)=>{ctx.save();ctx.translate(d.x,d.y);ctx.rotate(d.angle);ctx.fillStyle=d.isPlayer?"#18c96e":["#e54b4b","#4287e5","#e5a63f","#9b62c4"][i-1];ctx.fillRect(-23,-13,46,26);ctx.fillStyle="#111";ctx.fillRect(-7,-16,14,7);ctx.restore()});
    ctx.restore();
  }
  function updateHUD(){
    const rank=[...race.drivers].sort((a,b)=>b.progress-a.progress).findIndex(d=>d.isPlayer)+1;
    $("hudPosition").textContent=rank;$("hudTime").textContent=race.elapsed.toFixed(2);$("hudCourse").textContent=save.course;
    $("hudLap").textContent=Math.min(3,race.drivers[0].lap+1);
  }
  function finishRace(){
    if(race.finished)return;race.finished=true;cancelAnimationFrame(frame);
    const ranking=[...race.drivers].sort((a,b)=>b.progress-a.progress),pos=ranking.findIndex(d=>d.isPlayer)+1;
    const reward=[0,100,50,25,10][pos]||0;save.points+=reward;save.totalRaces++;save.course=Math.min(200,save.course+1);
    if(!save.bestPosition||pos<save.bestPosition)save.bestPosition=pos;
    if(save.bestTime==null||race.elapsed<save.bestTime)save.bestTime=race.elapsed;saveGame();
    $("resultsTitle").textContent=pos===1?"🏆 VICTOIRE !":"🏁 COURSE TERMINÉE !";$("resultsAnimation").textContent=pos===1?"🏆🎉":"🏎️";
    $("resultsList").innerHTML=ranking.map((d,i)=>`<div class="result-row ${d.isPlayer?"player":""}"><span>${["🥇","🥈","🥉","4️⃣","5️⃣"][i]||i+1}</span><strong>${d.name}</strong><span>${d.isPlayer?"+"+reward+" ⭐":""}</span></div>`).join("");
    $("rewardText").textContent=`Tu gagnes ${reward} point${reward>1?"s":""}. ⭐`;$("timeResult").textContent=`Temps : ${race.elapsed.toFixed(2)} s`;
    showScreen("resultsScreen");
  }
  $("raceBtn").addEventListener("click",()=>{if(!save.track){showScreen("editorScreen");requestAnimationFrame(resizeEditor);alert("Dessine d'abord ton circuit !");return}startRace()});
  $("continueBtn").addEventListener("click",()=>{updateMenu();showScreen("menuScreen")});
  $("leaveRaceBtn").addEventListener("click",()=>{if(!confirm("Quitter cette course ?"))return;race=null;cancelAnimationFrame(frame);accel=brake=false;Object.keys(keys).forEach(k=>keys[k]=false);resetJoystick();updateMenu();showScreen("menuScreen")});

  // Keyboard + touch
  window.addEventListener("keydown",e=>{const m={ArrowUp:"up",KeyW:"up",KeyZ:"up",ArrowDown:"down",KeyS:"down",ArrowLeft:"left",KeyA:"left",KeyQ:"left",ArrowRight:"right",KeyD:"right"};if(m[e.code]){keys[m[e.code]]=true;e.preventDefault()}});
  window.addEventListener("keyup",e=>{const m={ArrowUp:"up",KeyW:"up",KeyZ:"up",ArrowDown:"down",KeyS:"down",ArrowLeft:"left",KeyA:"left",KeyQ:"left",ArrowRight:"right",KeyD:"right"};if(m[e.code])keys[m[e.code]]=false});
  function setupButton(el,set){el.addEventListener("pointerdown",e=>{e.preventDefault();set(true)});["pointerup","pointercancel","pointerleave"].forEach(ev=>el.addEventListener(ev,e=>{e.preventDefault();set(false)}))}
  setupButton($("accelerateBtn"),v=>accel=v);setupButton($("brakeBtn"),v=>brake=v);
  const je=$("joystick"),jk=$("joystickKnob");
  function updateJoy(x,y){const r=je.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2,max=r.width/2-32;let dx=x-cx,dy=y-cy,l=Math.hypot(dx,dy);if(l>max){dx=dx/l*max;dy=dy/l*max}joy.x=dx/max;joy.y=dy/max;jk.style.transform=`translate(${dx}px,${dy}px)`}
  function resetJoystick(){joy.x=0;joy.y=0;joy.active=false;jk.style.transform="translate(0,0)"}
  je.addEventListener("pointerdown",e=>{e.preventDefault();joy.active=true;je.setPointerCapture?.(e.pointerId);updateJoy(e.clientX,e.clientY)});
  je.addEventListener("pointermove",e=>{if(joy.active){e.preventDefault();updateJoy(e.clientX,e.clientY)}});
  ["pointerup","pointercancel"].forEach(ev=>je.addEventListener(ev,resetJoystick));

  function init(){
    if(save.avatar){loadAvatarForm();$("avatarHeading").textContent="Crée ton pilote";$("createAvatarBtn").textContent="💾 Enregistrer les modifications";updateMenu();showScreen("menuScreen")}
    else {updateAvatarPreview();showScreen("avatarScreen")}
  }
  init();
});